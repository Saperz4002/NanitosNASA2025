(() => {
  const normalize = (s) =>
    (s || "")
      .toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim();

  const FALLBACK_PLANETS = [
    { name: "Kepler-227 b", id: "KIC 8692861 b" }
  ];
  const PLANETS_LIST = (window.PLANET_IDS && Array.isArray(window.PLANET_IDS) && window.PLANET_IDS.length)
    ? window.PLANET_IDS
    : FALLBACK_PLANETS;

  const CATALOG = [
    {
      keyAliases: ["kepler-227 b", "kic 8692861 b", "kepler 227b", "k227b"],
      name: "Kepler-227 b",
      id: "KIC 8692861 b",
      image: "assets/img/k227b.jpg",
      data: {
        "Discovery Method": "Transit (Kepler)",
        "Host Star": "Kepler-227",
        "Realness score (0–1)": 0.999
      },
      predictions: {
        "0 = FALSE POSITIVE": 0.3643,
        "1 = CANDIDATE": 0.2527,
        "2 = CONFIRMED": 0.3829
      },
      description: "Predicted class: 2 (CONFIRMED)."
    }
  ];

  const INDEX = new Map();
  for (const item of CATALOG) {
    INDEX.set(normalize(item.name), item);
    INDEX.set(normalize(item.id), item);
    for (const alias of item.keyAliases) {
      INDEX.set(normalize(alias), item);
    }
  }

  const $ = (sel) => document.querySelector(sel);
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);
  const formatProb = (v) => (typeof v === "number" ? v.toFixed(4) : v);

  function renderItem(item) {
    const result = $("#result");
    if (!result) return;

    const rows = Object.entries(item.data || {})
      .map(([k, v]) => `<tr><th scope="row">${k}</th><td>${v}</td></tr>`)
      .join("");

    let predBlock = "";
    if (item.predictions && typeof item.predictions === "object") {
      let topKey = null;
      let topVal = -Infinity;
      for (const [k, v] of Object.entries(item.predictions)) {
        const num = typeof v === "number" ? v : parseFloat(v);
        if (!Number.isNaN(num) && num > topVal) {
          topVal = num;
          topKey = k;
        }
      }
      const predRows = Object.entries(item.predictions)
        .map(([k, v]) => {
          const isTop = k === topKey;
          return `<tr${isTop ? ' class="table-success"' : ""}>
                    <th scope="row">${k}</th>
                    <td>${formatProb(v)}</td>
                  </tr>`;
        })
        .join("");

      const topBadge = topKey
        ? `<span class="badge bg-success ms-2"> ${topKey} (${formatProb(topVal)})</span>`
        : "";

      predBlock = `
        <div class="mt-3">
          <h6 class="mb-2">Class probabilities ${topBadge}</h6>
          <div class="table-responsive">
            <table class="table table-sm table-striped align-middle">
              <tbody>${predRows}</tbody>
            </table>
          </div>
        </div>
      `;
    }

    result.innerHTML = `
      <div class="card shadow-sm mb-3">
        <img src="${item.image}" class="card-img-top" alt="${item.name}" onerror="this.style.display='none';">
        <div class="card-body">
          <h5 class="card-title">${item.name}</h5>
          <h6 class="card-subtitle mb-2 text-muted">${item.id}</h6>
          <p class="card-text">${item.description || ""}</p>

          <div class="table-responsive">
            <table class="table table-sm table-striped">
              <tbody>${rows}</tbody>
            </table>
          </div>

          ${predBlock}

          <button id="btnClear" class="btn btn-outline-secondary btn-sm mt-3">Limpiar</button>
        </div>
      </div>
    `;

    const btnClear = $("#btnClear");
    on(btnClear, "click", () => {
      const input = $("#userQuery");
      if (input) input.value = "";
      result.innerHTML = "";
      input?.focus();
    });
  }

  function renderNotFound(query, suggestions = []) {
    const result = $("#result");
    if (!result) return;

    const sugHtml = suggestions
      .slice(0, 5)
      .map((s) => `<li>${s.name} <span class="text-muted">(${s.id})</span></li>`)
      .join("");

    result.innerHTML = `
      <div class="alert alert-warning" role="alert">
        No results found for <strong>${query}</strong>.
        ${suggestions.length ? `<hr><div><strong>Maybe you are referring to:</strong><ul>${sugHtml}</ul></div>` : ""}
      </div>
    `;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const input = $("#userQuery");
    const q = normalize(input?.value || "");
    if (!q) {
      renderNotFound("(vacío)");
      return;
    }

    const exact = INDEX.get(q);
    if (exact) {
      renderItem(exact);
      return;
    }

    const partial = CATALOG.filter((it) =>
      normalize(it.name).includes(q) ||
      normalize(it.id).includes(q) ||
      it.keyAliases.some((a) => normalize(a).includes(q))
    );

    if (partial.length === 1) {
      renderItem(partial[0]);
      return;
    }

    const suggests = PLANETS_LIST.filter((p) =>
      normalize(p.name).includes(q) || normalize(p.id).includes(q)
    );
    renderNotFound(input?.value || "", suggests);
  }

  function init() {
    const form = $("#search-form");
    const result = $("#result");
    if (!form || !result) return;
    on(form, "submit", handleSubmit);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
