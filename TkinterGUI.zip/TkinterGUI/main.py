import eel
import os

eel.init('web')

eel.start('index.html', mode=None, host='0.0.0.0', port=5000, block=True)


